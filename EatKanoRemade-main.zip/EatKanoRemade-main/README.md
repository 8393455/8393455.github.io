# EatKanoRemade
小游戏：吃掉小鹿乃（重制版）
# 视频&试玩
[在 Github Pages 中试玩](https://bugteas.github.io/EatKanoRemade/index.html)|[视频 Bilibili](https://www.bilibili.com/video/av80433022)
## 介绍
  创作灵感来源于[arcxingye/EatKano](https://github.com/arcxingye/EatKano),但代码全部重写，使用原生JavaScript＋CSS3动画，个性化程度极高，背景，按键边框，图案，音效都支持自定义编辑，可以分为两个部分独立设置，甚至可以将HTML代码作为按键样式！
## 配置修改
  在index.html的底部，你可以通过修改配置代码进行默认的参数设置，比如默认游戏模式、个性化主题，虽然都可以在游戏的主页中直接设置，但配置代码中的配置是开盖即食的，页面加载完毕后无须进行设置即可享用，具体修改方法见视频
